<!DOCTYPE html>
<html>
<head>
<style>
img {
  border-radius: 8px;
}
body {
  background-image: url('https://images.squarespace-cdn.com/content/v1/5644bc92e4b0d1606755bcbe/1519157913418-Q4IP2QLZKQR6P6VKBUBU/ke17ZwdGBToddI8pDm48kFmfxoboNKufWj-55Bgmc-J7gQa3H78H3Y0txjaiv_0fDoOvxcdMmMKkDsyUqMSsMWxHk725yiiHCCLfrh8O1z4YTzHvnKhyp6Da-NYroOW3ZGjoBKy3azqku80C789l0iXS6XmVv7bUJ418E8Yoc1hjuviiiZmrL38w1ymUdqq4JaGeFUxjM-HeS7Oc-SSFcg/Hall+of+Fame+001.jpg?format=2500w');
  background-repeat: no-repeat;
}
table {
  width:100%;
}
table, td {
  border: 1px solid black;
  
  background-color: white;
}
th, td {
  padding: 15px;
  text-align: left;
}
table, th {
  background-color: skyblue;
  border-collapse: collapse;
}
</style>
<head>
<body>
<h2> <center> Available Fields at School</center></h2>
<table style="width:100%">
<tr>
	<th> Commerce</th>
	<th> Science </th>
	<th> Social Science</th>
	<th> Art</th>
<tr>
<tr>
    <td>English as First Language</td>
    <td>English as First Languageh</td>
    <td>English as First Language</td>
	<td>English as First Language</td>
  </tr
  <tr>
    <td>Math</td>
    <td>Math</td>
    <td>Math</td>
	<td>Art & Design</td>
  </tr
  <tr>
    <td>Economics</td>
    <td>Biology</td>
    <td>Business Studies</td>
	<td>Music</td>
  </tr
  <tr>
    <td>Accounting</td>
    <td>Physics</td>
    <td>Geography</td>
	<td>Digital Intelligence</td>
  </tr
  <tr>
    <td>Subject of Choice</td>
    <td>Chemistry</td>
    <td>Life Skills</td>
	<td>Physical Education</td>
  </tr
  <tr>
    <td>Computer Science</td>
    <td>Computer Science</td>
    <td>Computer Science</td>
	<td>Computer Science</td>
  </tr

</body>
</html>